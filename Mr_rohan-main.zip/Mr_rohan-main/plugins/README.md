<p align="center">
  <img src="https://graph.org/file/18ea3932a8d72f6753529.jpg" alt="Jisshu-Auto-filter">
</p>
<h1 align="center">
  <a href="https://telegram.me/JISSHU_BOTS">Jisshu Auto filter</a>
</h1>
<img src="https://cdn.jsdelivr.net/gh/Jisshubot/Jisshubot/resources/hr.gif"/>

<img src="https://github.com/Jisshubot/Jisshubot/blob/master/resources/hr.gif"/>
<h1> <img src="https://graph.org/file/9b3bac6be700d65e96c7b.jpg" width="70px" style="border-radius: 50%"> ᴄᴏɴᴛᴀᴄᴛ ᴍᴇ </h1>
  
[<img src="https://raw.githubusercontent.com/Jisshubot/Jisshubot/master/resources/telegram_icon.png" width="60px">](https://telegram.im/@JISSHU_BOTS) [<img src="https://raw.githubusercontent.com/AnonymousX1025/AnonymousX1025/master/resources/github_icon.png" width="60px">](https://github.com/Jisshubot) [<img src="https://raw.githubusercontent.com/AnonymousX1025/AnonymousX1025/master/resources/youtube_icon.png" width="60px">](https://www.youtube.com/@JISSHU-BOTS) [<img src="https://github.com/AnonymousX1025/AnonymousX1025/blob/master/resources/insta_icon.png" width="60px">](https://instagram.com/Zishan_khan565)

<img src="https://cdn.jsdelivr.net/gh/Jisshubot/Jisshubot/resources/hr.gif"/>

